import java.util.*;

public class conditions {
    public static void main(String[] args) {
        // Scanner = new Scanner(System.in);
        // int x = sc.nextInt();
        // if (x % 2 == 0) {
        // System.out.println("even");
        // } else {
        // System.out.println("odd");}
        // int a = sc.nextInt();
        // int b = sc.nextInt();
        // if (a > b) {
        // System.out.println("a is greater");
        // } else {
        // if (a < b) {
        // System.out.println("b is greater");
        // } else {
        // System.out.println("equals");
        // }
        // }
        // }
        // }
        // ELSE IF CONDITIONS
        if (a == b) {
            System.out.println("equal");
        } else if (a > b) {
            System.out.println("a is greater");
        } else {
            System.out.println("b is greater");
        }
    }
}